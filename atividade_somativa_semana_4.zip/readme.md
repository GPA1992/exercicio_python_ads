## Gabriel Proença

### Atividade Somativa 

- Para executar a atividade rode o arquivo `ATIVIDADE_SOMATIVA-1.py` e siga o fluxo de menu!
  
> python3 ATIVIDADE_SOMATIVA-1.py