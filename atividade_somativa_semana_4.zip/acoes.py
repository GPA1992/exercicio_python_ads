act1 = """

====== INCLUSÃO ======
"""

act2 = """

====== EXIBIÇÃO ======

"""

act3 = """

====== ATUALIZAÇÃO ======

"""

act4 = """

====== EXCLUSÃO ======

"""

act9 = """

====== VOLTAR AO MENU PRINCIPAL ======

"""
